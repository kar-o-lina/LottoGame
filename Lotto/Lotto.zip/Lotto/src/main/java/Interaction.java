import java.util.Set;

public interface Interaction {

    Set<Integer> getUserInput();
    void printMessageToUser(String indicative);

}
