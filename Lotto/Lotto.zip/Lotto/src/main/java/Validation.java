import java.util.Set;

public interface Validation {
    boolean validateUserInput(Set<Integer> userGuesses);
    boolean isNumberInBounds(int guess);
}
