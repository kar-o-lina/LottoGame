import java.util.*;

public class GameLogic {

    private GameHelper helper;
    private Interactor interactor;

    public GameLogic() {
        this.helper = new GameHelper();
        this.interactor = new Interactor();
    }

    public void play() {
        interactor.getUserInput();
       // System.out.println(interactor.getUserGuesses());
        helper.printGeneratedNumbers();
        helper.checkGameOutcome();
    }

}

