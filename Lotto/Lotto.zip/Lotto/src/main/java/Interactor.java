import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Interactor implements Interaction, Validation {

    private final Set<Integer> userGuesses;

    public Interactor() {
        this.userGuesses = new HashSet<>();
    }

    public Set<Integer> getUserGuesses() {
        return userGuesses;
    }

    @Override
    public Set<Integer> getUserInput() {
        Scanner scanner = new Scanner(System.in);
        printMessageToUser("prompt");

        do {
            while (!scanner.hasNextInt()) {
                scanner.next();
                printMessageToUser("invalid");
            }
            int userInput = scanner.nextInt();

            if (!isNumberInBounds(userInput)) {
                printMessageToUser("out of bounds");
            } else {
                userGuesses.add(userInput);
            }
        } while ((userGuesses.size() < GameHelper.NUMBERS_TO_GENERATE));

        //System.out.println(userGuesses.isEmpty());

        return userGuesses;
    }

    @Override
    public void printMessageToUser(String indicative) {

        //tu można zrobić mapę

        switch (indicative) {
            case "prompt" -> System.out.println("Please enter 6 numbers between 1 and 99:");
            case "invalid" -> System.out.println("Invalid user input. Enter numbers only.");
            case "win" -> System.out.println("Congratulations! You won!");
            case "lost" -> System.out.println("\nYou didn't win this time. \nMaybe next time?");
            //gdzie jest zawartość seta userGuesses??
            case "guesses" -> System.out.println("\nYour guesses: " + "\n" + userGuesses);
            case "out of bounds" -> System.out.println("Number out of bounds. Valid numbers: 1 - 99.\nPlease choose again: ");
            default -> System.out.println("");
        }
    }

    @Override
    public boolean validateUserInput(Set<Integer> userGuesses) {
        for (int guess : userGuesses) {
            if (isNumberInBounds(guess)) {
                continue;
            } else {
                printMessageToUser("out of bounds");
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean isNumberInBounds(int guess) {
        return guess < 100 && guess > 0;
    }
}
