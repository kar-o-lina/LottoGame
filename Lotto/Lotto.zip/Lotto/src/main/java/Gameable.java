import java.util.Set;

public interface Gameable {

    Set<Integer> generateRandomNumbers();
    void printGeneratedNumbers();
    void checkGameOutcome();
}
