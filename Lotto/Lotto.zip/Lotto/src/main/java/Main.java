public class Main {

    public static void main(String[] args) {
        GameLogic game = new GameLogic();
        game.play();
    }
}
