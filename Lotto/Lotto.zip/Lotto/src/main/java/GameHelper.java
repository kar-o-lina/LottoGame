import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class GameHelper implements Gameable {

    private final Random random = new Random();
    static final int NUMBERS_TO_GENERATE = 6;
    private final Set<Integer> generatedNumbers;
    private Interactor interactor;

    public GameHelper() {
        this.generatedNumbers = new HashSet<>();
        this.interactor = new Interactor();
    }

    @Override
    public void checkGameOutcome() {

        interactor.printMessageToUser("guesses");

        if (generatedNumbers.containsAll(interactor.getUserGuesses()) && interactor.getUserGuesses().containsAll(generatedNumbers)) {
            interactor.printMessageToUser("won");
        } else {
            interactor.printMessageToUser("lost");
        }
    }

    @Override
    public Set<Integer> generateRandomNumbers() {
        while (generatedNumbers.size() < NUMBERS_TO_GENERATE) {
            int randomNumber = random.nextInt(1, 99);
            generatedNumbers.add(randomNumber);
        }
        return generatedNumbers;
    }

    @Override
    public void printGeneratedNumbers() {
        System.out.println("\nGenerating numbers.\n" +
                "\nNumbers generated are:\n" +
                generateRandomNumbers());
    }
}

